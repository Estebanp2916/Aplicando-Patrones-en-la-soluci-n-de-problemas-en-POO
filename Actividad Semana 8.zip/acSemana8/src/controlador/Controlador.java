
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Modelo;
import vista.Vista;
import javax.swing.JFrame;

/**
 *   
 * @author Esteban
 */
public class Controlador implements ActionListener{
    
    private Vista vista;
    private Modelo modelo;
    
    public Controlador(Vista vista, Modelo modelo){
        
        this.vista = vista;
        this.modelo = modelo;
        this.vista.btnSalir.addActionListener(this);
        this.vista.btnRegistrar.addActionListener(this);
     }
    
     public void iniciar(){
            vista.pack();
            vista.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            vista.setLocationRelativeTo(null);
            vista.setVisible(true);
        }
    
    public void actionPerformed(ActionEvent e){
       
           if (vista.btnRegistrar == e.getSource()) {
              
                modelo.guardarServicio(vista.txtServicio.getText());
                modelo.guardarFuncionario(vista.txtFuncionario.getText());
                modelo.guardarFecha(vista.txtFecha.getText());
                modelo.guardarDatos();
                vista.jTextArea1.setText(modelo.getTotal());
                vista.txtServicio.setText("");
                vista.txtFuncionario.setText("");
                vista.txtFecha.setText("");
          }
           if (vista.btnSalir == e.getSource()) {
            
               System.exit(0);
           }
    }
}
