
package acsemana8;

import controlador.Controlador;
import modelo.Modelo;
import vista.Vista;

public class AcSemana8 {

    public static void main(String[] args) {
        
        Modelo mod = new Modelo();
        Vista vis = new Vista();
        Controlador con = new Controlador(vis, mod);
        con.iniciar();
    }    
}