
package modelo;

public class Modelo {
    private String tipServicio;
    private String fun;
    private String fecha;
    private int n = -1; 
   
    String[] datos = new String [100];
    private String total = "Datos Del Día";
    private int i = 0;

    public String getTipServicio() {
        return tipServicio;
    }

    public void setTipServicio(String tipServicio) {
        this.tipServicio = tipServicio;
    }

    public String getFun() {
        return fun;
    }

    public void setFun(String fun) {
        this.fun = fun;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public void guardarServicio(String servicio){

        setTipServicio(servicio + "  ");
    }
    public void guardarFuncionario(String funcionario){

        setFun(funcionario + "  ");
    }
    public void guardarFecha(String fecha){

        setFecha(fecha + "  ");
    }
    public void guardarDatos(){
        int j = i +1;
        setN(++n);
        while(i < datos.length && j > i){
            if (getN() == i){
                datos[i] = getTipServicio() + getFun() + getFecha();
                total = total + "\n" + datos[i];
                ++i;
            }    
            else{
                j = 0;
            }
        }
    }
}
